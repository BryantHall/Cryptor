package cryptor;

/**
 * 
 * @author Bryant Hall & Yihao Fu
 * @version 2018-3-03
 * 
 *  This class takes a String and will encrypt the String to an un-readable String.
 */
public class Encryptor
{   
    /**
     * String array of words to encrypt
     */
    private String[] words;
    
    /**
     * Constructor for Encryptor 
     * @param phrase  a String to encrypt
     */
    public Encryptor(String phrase)
    {
        words = phrase.split(" ");
        
    }    
    
    /**
     * Method to replace the vowels of the words in the phrase
     * The Key is: a = i
     *             e = o
     *             i = u
     *             o = a
     *             u = e
     *  Every consonant is shifted to the right one place
     *  Vowels are skipped
     *  Ex: b=c c=d d=f , notice e is skipped
     */
    public void switchLetters()
    {
        // initialize variable references
        String[] switchedWords = new String[words.length];
        String word;
        char letter;
        String newWord;
        
        // cycle through the String array
        for (int i = 0; i < words.length; ++i)
        {
            word = words[i];
            newWord = "";
            
            // cycle through the individual words
            for (int j = 0; j < word.length(); ++j)
            {
                letter = word.charAt(j);
                letter = Character.toLowerCase(letter);
                letter = lettersReplace(letter);
                
                // add letter to word
                newWord += letter;                                          
            }
            
            // add word to String array
            switchedWords[i] = newWord;
        }
        
        // copy String array
        words = switchedWords;
    }
    
    /**
     * Method to alter the vowels along the guidelines of the Key
     * @param letter  input letter to test
     * @return letter  altered form if letter was a vowel; if consonant, param == return
     */
    private char lettersReplace(char letter)
    {
        // vowel replace
        if (letter == 'a')
        {
            return letter = 'i';
        }
        else if (letter == 'e')
        {
            return letter = 'o';
        }
        else if (letter == 'i')
        {
            return letter = 'u';
        }
        else if (letter == 'o')
        {
            return letter = 'a';
        }
        else if (letter == 'u')
        {
            return letter = 'e';
        }
        
        //consonant shift
        else if (letter == 'b')
        {
            return letter = 'c';
        }
        else if (letter == 'c')
        {
            return letter = 'd';
        }
        else if (letter == 'd')
        {
            return letter = 'f';
        }
        else if (letter == 'f')
        {
            return letter = 'g';
        }
        else if (letter == 'g')
        {
            return letter = 'h';
        }
        else if (letter == 'h')
        {
            return letter = 'j';
        }
        else if (letter == 'j')
        {
            return letter = 'k';
        }
        else if (letter == 'k')
        {
            return letter = 'l';
        }
        else if (letter == 'l')
        {
            return letter = 'm';
        }
        else if (letter == 'm')
        {
            return letter = 'n';
        }
        else if (letter == 'n')
        {
            return letter = 'p';
        }
        else if (letter == 'p')
        {
            return letter = 'q';
        }
        else if (letter == 'q')
        {
            return letter = 'r';
        }
        else if (letter == 'r')
        {
            return letter = 's';
        }
        else if (letter == 's')
        {
            return letter = 't';
        }
        else if (letter == 't')
        {
            return letter = 'v';
        }
        else if (letter == 'v')
        {
            return letter = 'w';
        }
        else if (letter == 'w')
        {
            return letter = 'x';
        }
        else if (letter == 'x')
        {
            return letter = 'y';
        }
        else if (letter == 'y')
        {
            return letter = 'z';
        }
        else if (letter == 'z')
        {
            return letter = 'b';
        }
        
        // any type of number or other character
        else
        {
            return letter;
        }
    }

    /**
     * A method to reverse the letters of the individual words
     */
    public void reverseWords()
    {
        //initialize variable references
        String[] switchedWords = new String[words.length];
        String word;
        char letter;
        String newWord;
        char punctuation;
        
        // cycle through the String array
        for (int i = 0; i < words.length; ++i)
        {
            word = words[i];
            newWord = "";
            punctuation = ' ';
            
            // cycle through individual words
            for (int j = 0; j < word.length(); ++j)
            {
                letter = word.charAt(word.length() - 1 - j);
                
                //check if letter is a punctuation
                if (letter == '.' || letter == ',' || letter == '?' || letter == '!' ||
                    letter == ':' || letter == ';') // could add more
                {
                    punctuation = letter;
                }
                //add letter to word
                else
                {
                    newWord += letter;
                }
                
                // add punctuation at end of word
                if (j + 1 == word.length() && punctuation != ' ')
                {
                    newWord += punctuation;
                }
            }
            // add word to new String Array
            switchedWords[i] = newWord;
        }
        //copy new String array 
        words = switchedWords;
    }
    
    /**
     * Method to reverse the order of String array
     */
    public void reverseStringArray()
    {
        //initialize variable references
        String[] switchedWords = new String[words.length];
        String word;
        
        //cycle through String array
        for (int i = 0; i < words.length; ++i)
        {
            //word at end is now the word at beginning
            word = words[words.length -1 - i];
            switchedWords[i] = word;
        }
        //copy new String Array
        words = switchedWords;
    }
    
    /**
     * String representation of altered phrase
     * @return String of word array
     */
    public String toString()
    {
        String output = "";
        
        //cycle through String array
        for (int i = 0; i < words.length; ++i)
        {
            //last word of array
            if (i + 1 == words.length)
            {
                output += words[i];
            }
            else
            {
                output += words[i] + " ";
            }
        }
        return output;
    }
}
