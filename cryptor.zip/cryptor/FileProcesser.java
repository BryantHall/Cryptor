package cryptor;

import java.io.*;

public class FileProcesser {
	
	/**
	 * Reads file.
	 * @param file
	 * file to be read
	 * @return cryptor file
	 * @throws IOException
	 * IO exception
	 */
	public static final CryptorFile readFile(File file) throws IOException {
		
		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		String nextLine = bufferedReader.readLine();
		String[] info = nextLine.split(" ");
		String text = new String();
		CryptorFile cpFile = new CryptorFile(info[0], null, true);
		
		nextLine = bufferedReader.readLine();
		
		if (info[1].equals("false")) {
			cpFile.setType(false);
		}
		
		while (nextLine != null) {
			text += nextLine;
			nextLine = bufferedReader.readLine();
		}
		
		cpFile.setText(text);
		bufferedReader.close();
		
		return cpFile;
	}
	
	/**
	 * Writes file.
	 * @param cpFile
	 * cryptor file
	 * @param file
	 * file to be write
	 * @throws IOException
	 * IO exception
	 */
	public static final void writeFile(CryptorFile cpFile, File file) throws IOException {
		
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));
		
		bufferedWriter.write(cpFile.getName() + " " + cpFile.getType() + "\n");
		bufferedWriter.write(cpFile.getText());	
		bufferedWriter.close();
	}
}
