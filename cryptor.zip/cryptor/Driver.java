package cryptor;

import javax.swing.DefaultListModel;

/**
 * Crypotor_Interface
 * @author Bryant Hall & Yihao Fu
 * @version 1.0
 * @date March 3, 2018
 */
public class Driver {

	public static DefaultListModel<CryptorFile> cryptorModel = new DefaultListModel<>();
	public static Interface cryptorInterface = new Interface();
	public static Controller controller = new Controller();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		cryptorInterface.setModel(cryptorModel);
		controller.setModel(cryptorModel);
		controller.setView(cryptorInterface);
		controller.launch();
	}
}
