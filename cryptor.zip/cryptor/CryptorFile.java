package cryptor;

/**
 * Crypotor_Interface
 * @author Bryant Hall & Yihao Fu
 * @version 1.0
 * @date March 3, 2018
 */
public class CryptorFile {

	private String name;
	private String text;
	private boolean type;
	
	/**
	 * Constructs a cryptor file.
	 */
	public CryptorFile() {
		
		this.name = new String();
		this.text = new String();
		this.type = true;
	}
	
	/**
	 * Constructs a crypotr file with data
	 * @param name
	 * file name
	 * @param text
	 * file text
	 * @param type
	 * file type
	 */
	public CryptorFile(String name, String text, boolean type) {
		
		this.name = name;
		this.text = text;
		this.type = type;
	}
	
	/**
	 * Gets file name
	 * @return a string of file name
	 */
	public final String getName() {
		
		return this.name;
	}
	
	/**
	 * Sets file name.
	 * @param name
	 * a string of file name
	 */
	public final void setName(String name) {
		
		this.name = name;
	}
	
	/**
	 * Gets text.
	 * @return a string of text
	 */
	public final String getText() {
		
		return this.text;
	}
	
	/**
	 * Sets text.
	 * @param text
	 * file text
	 */
	public final void setText(String text) {
		
		this.text = text;
	}
	
	/**
	 * Sets type.
	 * @param type
	 * file type
	 */
	public final void setType(boolean type) {
		
		this.type = type;
	}
	
	/**
	 * Gets type.
	 * @return type
	 */
	public final boolean getType() {
		
		return this.type;
	}
	
	/**
	 * Compares to other object.
	 * @param object
	 * object to compared
	 * @return -1, 0 or 1
	 */
	public final int compareTo(CryptorFile object) {
		
		return name.compareTo(object.getName());
	}

	@Override
	public final String toString() {
	
		return this.name;
	}
	
	@Override
	public final boolean equals(Object o) {
		
		CryptorFile object = (CryptorFile)o;
		
		if (this.name.equals(object.getName())) {
			return true;
		}
		else {
			return false;
		}
	}
}
