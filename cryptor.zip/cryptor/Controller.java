package cryptor;

import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 * Crypotor_Interface
 * @author Bryant Hall & Yihao Fu
 * @version 1.0
 * @date March 3, 2018
 */
public final class Controller {

	private DefaultListModel<CryptorFile> cryptorModel;
	private Interface cryptorInterface;
	
	/**
	 * Constructs a controller.
	 */
	public Controller() {
		
		this.cryptorModel = new DefaultListModel<>();
		this.cryptorInterface = new Interface();
	}
	
	/**
	 * Sets model.
	 * @param cryptorModel
	 * cryptor model
	 */
	public final void setModel(DefaultListModel<CryptorFile> cryptorModel) {
		
		this.cryptorModel = cryptorModel;
	}
	
	/**
	 * 
	 * @param cryptorInterface
	 */
	public final void setView(Interface cryptorInterface) {
		
		this.cryptorInterface = cryptorInterface;
	}
	
	/**
	 * Launches this controller.
	 */
	public final void launch() {
		
		this.cryptorInterface.registerInterfaceListener(new InterfaceListener());
		this.cryptorInterface.registerListListener(new ListListener());
		//this.cryptorInterface.setModel(this.cryptorModel);
		this.cryptorInterface.setVisible(true);
	}
	
	/**
	 * Converts text.
	 */
	private final void convert() {
		
		if (this.cryptorInterface.getInput().length() > 0) {
			if (this.cryptorInterface.checkType()) {
				if (this.cryptorInterface.isEnc()) {
					Encryptor encryptor = new Encryptor(this.cryptorInterface.getInput());   
					encryptor.reverseStringArray();
					encryptor.reverseWords();
					encryptor.switchLetters();
					this.cryptorInterface.setOutput(encryptor.toString());
				}
				else {
					Decryptor decryptor = new Decryptor(this.cryptorInterface.getInput());
					decryptor.unReverseStringArray();
					decryptor.unReverseWords();
					decryptor.unSwitchLetters();
					this.cryptorInterface.setOutput(decryptor.toString());
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Please select one type to convert.", null, 2);
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "Sorry, cannot convert a blank text.", null, 2);
		}
	}
	
	/**
	 * Imports file.
	 * @throws IOException
	 * IO exception. 
	 */
	private void importFile() throws IOException {
		
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Choose a File");
		
		// Import file.
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			File file = fileChooser.getSelectedFile();
			if (file.exists()) {
				CryptorFile cpFile = FileProcesser.readFile(file);
				this.cryptorModel.addElement(cpFile);
			}
			else {
				JOptionPane.showMessageDialog(null, "Sorry, file not found.", null, 2);
			}
		}
	}
	
	/**
	 * Exports file.
	 * @throws IOException
	 * IO exception.  
	 */
	private void exportFile() throws IOException {
		
		int selected = this.cryptorInterface.getSelection();
		
		if (selected >= 0) {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setDialogTitle("Make a File");
			if (fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
				File file = fileChooser.getSelectedFile();
				if (!file.getName().contains(".txt")) {
					file = new File(file.getName() + ".txt");
					CryptorFile cpFile = this.cryptorModel.get(selected);
					FileProcesser.writeFile(cpFile, file);
				}
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "Sorry, please select a file.", null, 2);
		}	
	}
	
	/**
	 * Adds a file.
	 */
	private final void add() {
		
		boolean added = false;
		
		if (this.cryptorInterface.getInput().length() != 0) {
			if (this.cryptorInterface.checkType()) {
				String fileName = JOptionPane.showInputDialog(null, "Please enter a file name.");
				if (fileName != null) {
					String fileData = this.cryptorInterface.getInput();
					int position = this.binarySearch(fileName, 0, this.cryptorModel.size()-1);
					if (position != -1) {
						int option = JOptionPane.showConfirmDialog(null, fileName + " already exists.\nDo you want to replace the file?", null, 2, 3);
						if (option == 0) {
							this.cryptorModel.get(position).setText(fileData);
							added = true;
						}
					}
					else {
						CryptorFile cpFile = new CryptorFile(fileName, fileData, this.cryptorInterface.isEnc());
						this.cryptorModel.addElement(cpFile);
					}
					if (added) {
						this.mergeSort(0, this.cryptorModel.size()-1);
						this.cryptorInterface.setModel(this.cryptorModel);
						this.cryptorInterface.refresh();	
					}
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Please select one type to save.", null, 2);
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "Sorry, cannot save a blank text.", null, 2);
		}
	}
	
	/**
	 * Clear all of texts on interface.
	 */
	private final void clear() {
		
		this.cryptorInterface.setInput("");
		this.cryptorInterface.setOutput("");
	}

	/**
	 * Deletes file. 
	 */
	private final void delete() {
		
		int selection = cryptorInterface.getSelection();
		
		if (selection >= 0) {
			this.cryptorModel.remove(cryptorInterface.getSelection());
			this.cryptorInterface.refresh();
		}
		else {
			JOptionPane.showMessageDialog(null, "Please select a file to be removed.", null, 2);
		}
	}
	
	/**
	 * Clears all of files.
	 */
	private final void clearAll() {
		
		this.cryptorModel.clear();
		this.cryptorInterface.refresh();
	}

	/**
	 * Refreshes interface.
	 * @param number
	 * number of type
	 */
	private final void refreshType(int number) {
		
		this.cryptorInterface.deselected(number);
	}
	
	/**
	 * Searches file by using binary search.
	 * @param target
	 * target to be searched
	 * @param lowIndex
	 * low index
	 * @param highIndex
	 * high index
	 * @return -1 or position of target
	 */
	private final int binarySearch(String target, int lowIndex, int highIndex) {
		
		if (lowIndex > highIndex) {
			return -1;
		}
		else {
			int midIndex = lowIndex + (highIndex-lowIndex) / 2;
			if (target.equals(this.cryptorModel.get(midIndex).getName())) {
				return midIndex;
			}
			else if (target.compareTo(this.cryptorModel.get(midIndex).getName()) < 0) {
				return this.binarySearch(target, lowIndex, midIndex-1);
			}
			else {
				return this.binarySearch(target, midIndex+1, highIndex);
			}
		}
	}

	/**
	 * Sorts file list by using merge sort.
	 * @param lowIndex
	 * low index
	 * @param highIndex
	 * high index
	 */
	private final void mergeSort(int lowIndex, int highIndex) {
		
		if (lowIndex < highIndex) {
			int midIndex = lowIndex + (highIndex-lowIndex) / 2;
			this.mergeSort(lowIndex, midIndex);
			this.mergeSort(midIndex+1, highIndex);
			for (int i = midIndex; i <= highIndex; ++i) {
				for (int j = i; j > lowIndex; --j) {
					if (this.cryptorModel.get(j-1).compareTo(this.cryptorModel.get(j)) > 0) {
						CryptorFile temp = this.cryptorModel.get(j-1);	
						this.cryptorModel.set(j-1, this.cryptorModel.get(j));
						this.cryptorModel.set(j, temp);
					}
					else {
						break;
					}
				}
			}
		}
	}
	
	/**
	 * Interface listener class.
	 */
	public final class InterfaceListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent actionEvent) {
			
			switch(actionEvent.getActionCommand()) {
			//TODO Import export
			case "Import": 
				try {
					importFile();
				} catch (IOException e) {
					throw new IllegalArgumentException("Cannot import file.");
				} break;
			case "Export": 
				try {
					exportFile();
				} catch (IOException e) {
					throw new IllegalArgumentException("Cannot export file.");
				} break;
			case "Delete": delete(); break;
			case "ClearAll": clearAll(); break;
			case "Convert": convert(); break;
			case "Save": add(); break;
			case "Clear": clear(); break;
			case "Encryptor": refreshType(0); break;
			default: refreshType(1); break;
			}
		}
	}
	
	/**
	 * List selection listener class.
	 */
	public final class ListListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent listSelectionEvent) {
			
			int selected = cryptorInterface.getSelection();
			if (selected >= 0) {
				cryptorInterface.setInput(cryptorModel.get(selected).getText());
				cryptorInterface.setType(cryptorModel.get(selected));
				convert();
			}
		}
	}
}
