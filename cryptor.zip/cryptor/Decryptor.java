package cryptor;

/**
 * 
 * @author Bryant Hall & Yihao Fu
 * @version 2018/3/03
 *
 *  This class takes an encrypted String and re-structures the String to be readable.
 */
public class Decryptor
{
    /**
     * String array of words to decrypt
     */
    private String[] words;
    
    /**
     * Constructor for Decryptor
     * @param phrase  a string to decrypt
     */
    public Decryptor(String phrase)
    {
        words = phrase.split(" ");       
    } 
    
    /**
     * Method to replace the vowels of the words in the phrase
     * The Key is: i = a
     *             o = e
     *             u = i
     *             a = o
     *             e = u
     *             u = e
     *  Every consonant is shifted to the left one place
     *  Vowels are skipped
     *  Ex: c=b d=c f=d , notice e is skipped
     */
    public void unSwitchLetters()
    {
        //Initialize the variable references
        String[] switchedWords = new String[words.length];
        String word;
        char letter;
        String newWord;
        
        //cycle through the String array
        for (int i = 0; i < words.length; ++i)
        {
            word = words[i];
            newWord = "";
            
            //cycle through the individual words
            for (int j = 0; j < word.length(); ++j)
            {
                letter = word.charAt(j);
                letter = Character.toLowerCase(letter);
                letter = unLetterReplace(letter);
                
                //add letter to word
                newWord += letter;                                          
            }
            
            //add word to String array
            switchedWords[i] = newWord;
        }
        //copy String array
        words = switchedWords;
    }
    
    /**
     * Method to alter the vowels along the guidelines of the Key
     * @param letter  input letter to test
     * @return letter  altered form if letter was a vowel; if consonant, param == return
     */
    private char unLetterReplace(char letter)
    {
        //vowel shift
        if (letter == 'a')
        {
            return letter = 'o';
        }
        else if (letter == 'e')
        {
            return letter = 'u';
        }
        else if (letter == 'i')
        {
            return letter = 'a';
        }
        else if (letter == 'o')
        {
            return letter = 'e';
        }
        else if (letter == 'u')
        {
            return letter = 'i';
        }
        
        //consonant shift
        else if (letter == 'b')
        {
            return letter = 'z';
        }
        else if (letter == 'z')
        {
            return letter = 'y';
        }
        else if (letter == 'y')
        {
            return letter = 'x';
        }
        else if (letter == 'x')
        {
            return letter = 'w';
        }
        else if (letter == 'w')
        {
            return letter = 'v';
        }
        else if (letter == 'v')
        {
            return letter = 't';
        }
        else if (letter == 't')
        {
            return letter = 's';
        }
        else if (letter == 's')
        {
            return letter = 'r';
        }
        else if (letter == 'r')
        {
            return letter = 'q';
        }
        else if (letter == 'q')
        {
            return letter = 'p';
        }
        else if (letter == 'p')
        {
            return letter = 'n';
        }
        else if (letter == 'n')
        {
            return letter = 'm';
        }
        else if (letter == 'm')
        {
            return letter = 'l';
        }
        else if (letter == 'l')
        {
            return letter = 'k';
        }
        else if (letter == 'k')
        {
            return letter = 'j';
        }
        else if (letter == 'j')
        {
            return letter = 'h';
        }
        else if (letter == 'h')
        {
            return letter = 'g';
        }
        else if (letter == 'g')
        {
            return letter = 'f';
        }
        else if (letter == 'f')
        {
            return letter = 'd';
        }
        else if (letter == 'd')
        {
            return letter = 'c';
        }
        else if (letter == 'c')
        {
            return letter = 'b';
        }
        
        //any other number or character
        else
        {
            return letter;
        }
    }
    
    /**
     * A method to un-reverse the letters of the individual words
     */
    public void unReverseWords()
    {
        //initialize variable references
        String[] switchedWords = new String[words.length];
        String word;
        char letter;
        String newWord;
        char punctuation;
        
        // cycle through String array
        for (int i = 0; i < words.length; ++i)
        {
            word = words[i];
            newWord = "";
            punctuation = ' ';
            
            // cycle through individual words
            for (int j = 0; j < word.length(); ++j)
            {
                letter = word.charAt(word.length() - 1 - j);
                
                //check if letter is a punctuation
                if (letter == '.' || letter == ',' || letter == '?' || letter == '!' ||
                    letter == ':' || letter == ';') // could add more
                {
                    punctuation = letter;
                }
                //add letter to word
                else
                {
                    newWord += letter;
                }
                
                // add punctuation at end of word
                if (j + 1 == word.length() && punctuation != ' ')
                {
                    newWord += punctuation;
                }
            }
            
            // add word to String array
            switchedWords[i] = newWord;
        }
        //copy String array
        words = switchedWords;      
    }
    
    /**
     * Method to un-reverse the order of String array
     */
    public void unReverseStringArray()
    {
        //initialize reference variables
        String[] switchedWords = new String[words.length];
        String word;
        
        //cycle through the String array
        for (int i = 0; i < words.length; ++i)
        {
            word = words[words.length -1 - i];
            
            //add word to String array
            switchedWords[i] = word;
        }
        //copy String array
        words = switchedWords;
    }
    
    /**
     * String representation of altered phrase
     * @return String of word array
     */
    public String toString()
    {
        String output = "";
        
        //cycle through String array
        for (int i = 0; i < words.length; ++i)
        {
            //last word of array
            if (i + 1 == words.length)
            {
                output += words[i];
            }
            else
            {
                output += words[i] + " ";
            }
        }
        return output;
    }
}
