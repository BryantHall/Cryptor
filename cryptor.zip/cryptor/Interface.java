package cryptor;

import java.awt.*;
import javax.swing.*;
import cryptor.Controller.*;

/**
 * Crypotor_Interface
 * @author Bryant Hall & Yihao Fu
 * @version 1.0
 * @date March 3, 2018
 */
public final class Interface extends JFrame {

	private static final long serialVersionUID = 1L;
	private JMenuBar jmbMenuBar;
	private JMenu jmFile;
	private JMenuItem jmiImport, jmiExport, jmiDelete, jmiClear;
	private JPanel jpBase, jpInput, jpButtons;
	private JList<CryptorFile> jlFileName;
	private DefaultListCellRenderer dlcrFileName;
	private JLabel jlNote;
	private JTextArea jtaInput, jtaOutput;
	private JScrollPane jspFileName, jspInput, jspOutput;
	private JButton jbConvert, jbSave, jbClear;
	private JToolBar jtbType;
	private JRadioButton jrbEnc, jrbDec;
	private JSplitPane jspBase, jspTextArea;
	
	/**
	 * Constructs an inerface.
	 */
	public Interface() {
		
		this.jmbMenuBar = new JMenuBar();
		this.jmFile = new JMenu("File");
		this.jmiImport = new JMenuItem("Import");
		this.jmiExport = new JMenuItem("Export");
		this.jmiDelete = new JMenuItem("Delete");
		this.jmiClear = new JMenuItem("ClearAll");
		this.jpBase = new JPanel();
		this.jpInput = new JPanel();
		this.jpButtons = new JPanel();
		this.jlFileName = new JList<>();
		this.dlcrFileName = new DefaultListCellRenderer();
		this.jlNote = new JLabel();
		this.jtaInput = new JTextArea();
		this.jtaInput.setLineWrap(true); 
		this.jtaInput.setWrapStyleWord(true);
		this.jtaInput.setFont(this.jtaInput.getFont().deriveFont(16f));
		this.jtaOutput = new JTextArea();
		this.jtaOutput.setLineWrap(true); 
		this.jtaOutput.setWrapStyleWord(true);
		this.jtaOutput.setFont(this.jtaInput.getFont().deriveFont(16f));
		this.jspFileName = new JScrollPane(this.jlFileName);
		this.jspInput = new JScrollPane(this.jtaInput);
		this.jspOutput = new JScrollPane(this.jtaOutput);
		this.jbConvert = new JButton("Convert");
		this.jbSave = new JButton("Save");
		this.jbClear = new JButton("Clear");
		this.jtbType = new JToolBar();
		this.jrbEnc = new JRadioButton("Encryptor");
		this.jrbDec = new JRadioButton("Decryptor");
		this.jspBase = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		this.jspTextArea = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
		
		// Sets up default settings.
		this.setJMenuBar(this.jmbMenuBar);
		this.setTitle("Cryptor");
		this.setSize(800, 600);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(3);
		this.jpBase.setLayout(new BorderLayout());
		this.jpInput.setLayout(new BorderLayout());
		this.jlFileName.setSelectionMode(0);
		this.jlFileName.setFont(this.jlFileName.getFont().deriveFont(14f));
		this.jlFileName.setCellRenderer(this.dlcrFileName);
		this.dlcrFileName.setHorizontalAlignment(JLabel.CENTER);
		this.jlNote.setText("*English only");
		this.jlNote.setForeground(Color.RED);
		this.jtaOutput.setEditable(false);
		this.jspBase.setDividerLocation(120);
		this.jspTextArea.setDividerLocation(240);
				
		// Adds components.
		this.jmbMenuBar.add(this.jmFile);
		this.jmFile.add(this.jmiImport);
		this.jmFile.add(this.jmiExport);
		this.jmFile.add(this.jmiDelete);
		this.jmFile.add(this.jmiClear);
		this.jtbType.add(this.jrbEnc);
		this.jtbType.add(this.jrbDec);
		this.jpButtons.add(this.jbConvert);
		this.jpButtons.add(this.jbSave);
		this.jpButtons.add(this.jbClear);
		this.jpButtons.add(this.jtbType);
		this.jpInput.add(this.jlNote, BorderLayout.NORTH);
		this.jpInput.add(this.jspInput, BorderLayout.CENTER);
		this.jpInput.add(this.jpButtons, BorderLayout.SOUTH);
		this.jspBase.add(this.jspFileName, JSplitPane.LEFT);
		this.jspBase.add(this.jspTextArea, JSplitPane.RIGHT);
		this.jspTextArea.add(this.jpInput, JSplitPane.TOP);
		this.jspTextArea.add(this.jspOutput, JSplitPane.BOTTOM);
		this.jpBase.add(this.jspBase, BorderLayout.CENTER);
		this.add(this.jpBase, BorderLayout.CENTER);
	}
	
	/**
	 * Sets this interface is visible or not.
	 * @param visible
	 * true or false
	 */
	public final void visible(boolean visible) {
	
		this.setVisible(visible);
	}
	
	/**
	 * Sets model into this interface.
	 * @param cryptorModel 
	 * model of this file name list
	 */
	public final void setModel(DefaultListModel<CryptorFile> cryptorModel) {
	
		this.jlFileName.setModel(cryptorModel);
	}
	
	/**
	 * Refreshes the interface.
	 */
	public final void refresh() {
		
		this.jlFileName.updateUI();
		this.jtaInput.setText("");
		this.jtaOutput.setText("");
	}
	
	/**
	 * Gets input text of the input area.
	 * @return a string of input text
	 */
	public final String getInput() {
		
		return this.jtaInput.getText();
	}
	
	/**
	 * Sets input text into input field.
	 * @param text
	 * a string of input text
	 */
	public final void setInput(String text) {
		
		this.jtaInput.setText(text);
	}
	
	/**
	 * Sets output text into output field.
	 * @param text
	 * a string of output text
	 */
	public final void setOutput(String text) {
		
		this.jtaOutput.setText(text);
	}
	
	/**
	 * Gets the selection of file name list.
	 * @return index of the element
	 */
	public final int getSelection() {
		
		return this.jlFileName.getSelectedIndex();
	}
	
	/**
	 * Gets encoding type or decoding type.
	 * @return true or false
	 */
	public final boolean isEnc() {
		
		if (this.jrbEnc.isSelected()) {
			return true;
		}
			
		return false;
	}
	
	/**
	 * Checks type of encryptor or decryptor.
	 * @return true or false
	 */
	public final boolean checkType() {
		
		if (this.jrbEnc.isSelected() || this.jrbDec.isSelected()) {
			return true;
		}
			
		return false;
	}
	
	/**
	 * Sets type of cryptor file.
	 * @param cpFile
	 * cryptorFile
	 */
	public final void setType(CryptorFile cpFile) {
		
		if (cpFile.getType()) {
			this.jrbEnc.setSelected(true);
			this.jrbDec.setSelected(false);
		}
		else {
			this.jrbDec.setSelected(true);
			this.jrbEnc.setSelected(false);
		}
	}
	
	/**
	 * Deselects the specified ratio button.
	 * @param number
	 * number of the specified ratio button
	 */
	public final void deselected(int number) {
		
		if (number == 0) {
			jrbDec.setSelected(false);
		}
		else {
			jrbEnc.setSelected(false);
		}
	}
	
	/**
	 * Registers interface listener.
	 * @param interfaceListener
	 * interface listener
	 */
	public final void registerInterfaceListener(InterfaceListener interfaceListener) {
		
		this.jmiImport.addActionListener(interfaceListener);
		this.jmiExport.addActionListener(interfaceListener);
		this.jmiDelete.addActionListener(interfaceListener);
		this.jmiClear.addActionListener(interfaceListener);
		this.jbConvert.addActionListener(interfaceListener);
		this.jbSave.addActionListener(interfaceListener);
		this.jbClear.addActionListener(interfaceListener);
		this.jrbEnc.addActionListener(interfaceListener);
		this.jrbDec.addActionListener(interfaceListener);
	}
	
	/**
	 * Registers list listener.
	 * @param listListener
	 * list listener
	 */
	public final void registerListListener(ListListener listListener) {
		
		this.jlFileName.addListSelectionListener(listListener);
	}
}
